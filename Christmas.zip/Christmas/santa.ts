import { Actor, World } from './Simulator';

export class Santa extends Actor {

    private val = 0;
    private move = 0;
    private speed = 3;

    private mouseDragStartLocationOffsetElement = {
        x: 0,
        y: 0
    }

    constructor() {
        super();
        super.setImageSrc('./src/santa.png');
        super.scaleImageProportionateToWidth(40);

        

        window.addEventListener('keydown', e => {
            if(e.key == 'ArrowRight'){
                this.move = 1;
            }else if(e.key == 'ArrowLeft'){
                this.move = -1;
            }
        });

        window.addEventListener('keyup', e => {
            if(e.key == 'ArrowRight'){
                this.move = 0;
            }else if(e.key == 'ArrowLeft'){
                this.move = 0;
            }
        });

    }

    public addedToWorld(world: World){
          super.setLocation(50, 50, true, true);
    }

    public mouseEvent(e: MouseEvent){
        if(e.type == 'mousedown'){
            
            this.mouseDragStartLocationOffsetElement = super.getClickCoordinatesRelativeToActor(e.offsetX, e.offsetY);
            
            
        }
    }

    public dragging(x, y){
        
        super.setLocation(x - this.mouseDragStartLocationOffsetElement.x, y - this.mouseDragStartLocationOffsetElement.y);
    }

    public animate() {

        super.setX(super.getX() + this.move * this.speed);
        let y = super.getY();
        this.val+= 0.1;
        let cos = Math.cos(this.val);
        //super.setY(cos * 5 + y);
        
    }

}