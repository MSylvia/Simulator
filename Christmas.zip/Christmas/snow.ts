import { Actor, World, random } from './Simulator'

import { Snowflake } from './snowflake';

export class Snow extends Actor {

    private maxSnowFlakes = 200;


    constructor() {
        super();


    }

    public addedToWorld(world: World) {

        this.letItSnow();
    }

    private letItSnow(snowflakes = 10) {

        for (let i = 0; i < snowflakes; i++) {
            this.spawnSnowFlake();
        }
    }

    private spawnSnowFlake() {
        let worldWidth = super.getWorld().getWidth();
        let worldHeight = super.getWorld().getHeight();
        let xSpeed = (<HTMLInputElement>document.getElementById('slider')).valueAsNumber;

        if(random(10, 0) > 7 && xSpeed != 0){

            if(xSpeed < 0){
                super.getWorld().addToWorld(new Snowflake(), worldWidth, random(worldHeight));
            }else{
                super.getWorld().addToWorld(new Snowflake(), 0, random(worldHeight));
            }
            
        }else{
            super.getWorld().addToWorld(new Snowflake(), random(worldWidth, 0), 0);
        }

        
    }

    animate() {
        if(super.getWorld().getActors('Snowflake').length < this.maxSnowFlakes){
            this.spawnSnowFlake();
        }
    }
}