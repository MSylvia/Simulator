import {ChristmasWorld} from './christmasWorld';

let canvas = <HTMLCanvasElement>document.getElementById('canvas');
let ctx = canvas.getContext('2d');
let image = new Image();

let game = new ChristmasWorld(ctx);



window['game'] = game;