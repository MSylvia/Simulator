import { Santa } from './santa';
import { Present } from './present';
import { Snow } from './snow';

import { World, toRadians, scaleImageProportionateToWidth, scaleImageProportionateToHeight } from './Simulator';
export class ChristmasWorld extends World {

    santa: Santa;
    presents: Present[];
    y = 0;

    constructor(private ctx: CanvasRenderingContext2D) {
        
        super(ctx);

        super.setRenderingOrder('Santa', 'Present');
        this.setupBackground();

        let snow = new Snow();
        super.addToWorld(snow);

        this.presents = [];


        this.santa = new Santa();

        super.addToWorld(this.santa);


        ctx.canvas.addEventListener('dblclick', e => this.addPresent(e));

        this.animate();

    }

    setupBackground() {
        super.setBackgroundColor('#87CEFA');
        let background = new Image();
        background.src = './src/winter_scene.png';
        
        
        scaleImageProportionateToWidth(background, super.getWidth(), image => {
            super.useBackgroundImage(image);
        })

    }

    addPresent(e: MouseEvent) {
        let p = new Present();
        super.addToWorld(p, e.offsetX, e.offsetY);
        super.addToWorld(p, e.offsetX, e.offsetY);
    }

    public animate() {
        this.santa.setRotation(toRadians((<HTMLInputElement>document.getElementById('rot')).valueAsNumber));
        requestAnimationFrame(() => this.animate());
    }

}