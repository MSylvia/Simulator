import {World, Actor, getNewCtx, random} from './Simulator'

export class Snowflake extends Actor{

    private size: number;
    private speed: number;
    private lifetime: number = 0;

    constructor(){
        super();
        this.size = random(5, 2);
        this.speed = random(3, 1);
        
    }

    private generateFlakeImage(){
        let ctx = getNewCtx(10, 10);
        ctx.fillStyle = 'white';

        ctx.beginPath();
        ctx.arc(5, 5, this.size, 0, 2 * Math.PI);
        ctx.fill();
        ctx.closePath();

        super.setImageSrc(ctx.canvas.toDataURL());

    }

    public addedToWorld(world: World){
        this.generateFlakeImage();
    }

    public animate(){
        super.setY(super.getY() + this.speed);
        let xSpeed = (<HTMLInputElement>document.getElementById('slider')).valueAsNumber;
        super.setX(super.getX() + xSpeed);
        this.lifetime++;
        if(super.isAtEdge() && this.lifetime > 100) super.destroy();
    }
}