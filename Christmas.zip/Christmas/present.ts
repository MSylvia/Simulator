import { Actor, World, getNewCtx, random } from './Simulator';

export class Present extends Actor {

    private speedX: number = 0;
    private speedY: number = 0;

    constructor() {
        super();
        super.setImageSrc('./src/gift.png');
        super.scaleImageProportionateToWidth(30);

        /*while (this.speedX == 0 && this.speedY == 0) {
            this.speedX = random(3, -3);
            this.speedY = random(3, -3);
        }*/



    }

    private generateImage(world: World) {

        //Canvas
        let ctx = getNewCtx();
        ctx.canvas.width = world.getWidth();
        ctx.canvas.height = 20;

        //Fill
        ctx.fillStyle = 'green';
        ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);

        // Stroke
        ctx.strokeStyle = 'black';
        ctx.lineWidth = 10;
        ctx.strokeRect(0, 0, world.getWidth(), 20);

        // Set image
        super.setImageSrc(ctx.canvas.toDataURL());
    }

    public addedToWorld(world: World) {
        //this.generateImage(world);
    }

    public animate() {
        this.setLocation(this.getX() + this.speedX, this.getY() + this.speedY);
        if (this.isAtEdge()) {
            console.log('Should be destroyed');
            this.destroy();
        }
    }

}